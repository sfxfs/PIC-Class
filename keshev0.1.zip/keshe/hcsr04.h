#ifndef _HCSR_H
#define _HCSR_H

void hcsr_Init(void);
void hcsr_Trig(void);
void hcsr_DelayForDis(void);
float hcsr_GetDis(void);
void hcsr_Interrupt(void);

#endif