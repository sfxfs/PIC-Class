#include <htc.h>
#include <stdio.h>
#include <string.h>
__CONFIG(HS &WDTDIS &LVPDIS);

#include "lcd1602.h"
#include "hcsr04.h"
#include "motor.h"
#include "sensor.h"
#include "usart.h"

#define LS_TURN 10
#define LL_TURN 30
#define RS_TURN -10
#define RL_TURN -30
#define TURN_DIV 20

#define START_POINT_DELAY 10000
#define ROUND_TURN_DELAY 20000

#define S_ROUND round_count == 1 || round_count == 3
#define L_ROUND round_count == 2

unsigned char round_count = 0;
volatile char start_flag = 0;
volatile char too_close_flag = 0;
const int motor_init_value = 180;
int error, prev_error = 0; // 右转为正，左转为�?

char error_str[16] = {0};
char usart_str[16] = {0};
unsigned char usart_data = 0;
float hcsr_value;
// enum MOTOR_DIR left_temp = SIDE_STOP;
// enum MOTOR_DIR right_temp = SIDE_STOP;

void interrupt fxf(void)
{
    hcsr_Interrupt();
    sensor_Interrupt();
    usart_Interrupt();
}

main(void)
{
    LCD_Init();
    hcsr_Init();
    motor_Init(0, SIDE_STOP, SIDE_STOP);
    sensor_Init();
    usart_Init();

    for (;;)
    {
        if (start_flag && !too_close_flag)
        {

            if (round_count == 4)
            {
                motor_Write(0, SIDE_STOP, SIDE_STOP);
				for (;;);
            }

            switch (sensor_GetValue()) // 黑色高电�?
            {
            case 0b00000000:
                round_count++;
                for (size_t i = 0; i < START_POINT_DELAY; i++)
                {
                    asm("nop");
                }
                error = 0;
                break;

            case 0b11110000:
                if (prev_error == LL_TURN || prev_error == RL_TURN) // prev_error = 0b0xxx
                {
                    error = prev_error;
                }
                else
                {
                    error = 0;
                }
                break;

            case 0b10010000:
                error = 0;
                break;

            case 0b10110000:
                error = LS_TURN;
                break;

            case 0b01110000:
                error = LL_TURN;
                break;

            case 0b11010000:
                error = RS_TURN;
                break;

            case 0b11100000:
                error = RL_TURN;
                break;
                //=================round case=======================
            case 0b00110000:
                if (S_ROUND)
                {
                    motor_Write(motor_init_value, SIDE_GO, SIDE_BACK);
                    for (size_t i = 0; i < ROUND_TURN_DELAY; i++)
                    {
                        asm("nop");
                    }
                }
                if (L_ROUND)
                {
                    motor_Write(motor_init_value, SIDE_GO, SIDE_GO);
                    for (size_t i = 0; i < ROUND_TURN_DELAY; i++)
                    {
                        asm("nop");
                    }
                }
                break;

            case 0b00010000:
                if (S_ROUND)
                {
                    motor_Write(motor_init_value, SIDE_GO, SIDE_BACK);
                    for (size_t i = 0; i < ROUND_TURN_DELAY; i++)
                    {
                        asm("nop");
                    }
                }
                if (L_ROUND)
                {
                    motor_Write(motor_init_value, SIDE_GO, SIDE_GO);
                    for (size_t i = 0; i < ROUND_TURN_DELAY; i++)
                    {
                        asm("nop");
                    }
                }
                break;

            default:
                error = prev_error;
                break;
            }

            if (error == 0)
            {
                motor_Write(motor_init_value, SIDE_GO, SIDE_GO);
            }
            else if (error < 0 && error > -TURN_DIV)
            {
                motor_Write(motor_init_value + error, SIDE_STOP, SIDE_GO);
            }
            else if (error < -TURN_DIV)
            {
                motor_Write(motor_init_value + error, SIDE_BACK, SIDE_GO);
            }
            else if (error > 0 && error < TURN_DIV)
            {
                motor_Write(motor_init_value - error, SIDE_GO, SIDE_STOP);
            }
            else if (error > TURN_DIV)
            {
                motor_Write(motor_init_value - error, SIDE_GO, SIDE_BACK);
            }
        }
        else
        {
            motor_Write(0, SIDE_STOP, SIDE_STOP);
        }

        usart_data = usart_GetData();

        if (usart_data == 1)
        {
            start_flag = !start_flag;
        }

        hcsr_Trig();
        hcsr_DelayForDis();
        hcsr_value = hcsr_GetDis();
        if (hcsr_value <= 10)
        {
            too_close_flag = 1;
        }else
        {
            too_close_flag = 0;
        }

        // if (usart_data)
        // {
        sprintf(usart_str, "round:%d", round_count);
        // }

        sprintf(error_str, "hcsr:%.3f ", hcsr_value);

        LCD_ShowStr(usart_str, 0, 1);
        LCD_ShowStr(error_str, 0, 0);

        prev_error = error;
    }
}
