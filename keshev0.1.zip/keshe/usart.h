#ifndef _USART_H
#define _USART_H

void usart_Init(void);
void usart_Interrupt(void);
unsigned char usart_GetData(void);

#endif
