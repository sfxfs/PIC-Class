#include <htc.h>

#include "hcsr04.h"

#define TRIG_PIN RC3
#define TRIG_TRIS TRISC3
#define ECHO_PIN RC2
#define ECHO_TRIS TRISC2

volatile union short_div_t
{
    unsigned short raw;
    unsigned char div[2];
} distime;

void hcsr_Init(void)
{
    TRIG_TRIS = 0;
    TRIG_PIN = 0;
    ECHO_TRIS = 1;

    GIE = 1;
    PEIE = 1;

    TMR1IF = 0;
    T1CON = 0;
    TMR1H = 0;
    TMR1L = 0;
    TMR1IE = 1;

    CCP1IF = 0;
    CCP1CON = 0;
    CCP1IE = 1;

    CCP1CON = 0b101;	//start
}

void hcsr_Trig(void)
{
    TRIG_PIN = 1;

    asm("nop");
    asm("nop");
    asm("nop");
    asm("nop");
    asm("nop");
    asm("nop");
    asm("nop");
    asm("nop");
    asm("nop");
    asm("nop");
    asm("nop");

    TRIG_PIN = 0;
}

void hcsr_DelayForDis(void)
{
    for (unsigned char i = 0; i < 15; i++)
    {
        asm("nop");
    }
}

float hcsr_GetDis(void)
{
    return (0.034f * distime.raw);
}

void hcsr_Interrupt(void)
{
    if (CCP1IF && CCP1IE)
    {
        if (ECHO_PIN)
        {
            TMR1ON = 1;
            CCP1CON = 0b100;
        }

        if (!ECHO_PIN)
        {
            TMR1ON = 0;
            distime.div[0] = TMR1L;
            distime.div[1] = TMR1H;
			TMR1L = 0;
			TMR1H = 0;
            CCP1CON = 0b101;
        }
        CCP1IF = 0;
    }
}
