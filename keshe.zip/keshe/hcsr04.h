#ifndef _HCSR_H
#define _HCSR_H

void hcsr04_Init(void);
int hcsr04_GetDis(void);

#endif